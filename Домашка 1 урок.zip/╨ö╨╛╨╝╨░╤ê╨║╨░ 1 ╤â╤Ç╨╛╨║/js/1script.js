let name = prompt()
alert(`Hello, ${name}! How are you?`);